<head>
		<title>Tienda De Floris</title>
</head>
	<body>
		<?php include("header.php");?>
		<br/>
		
<form action="forgotpasswordhandler.php">



<tr ><!--style="background-image:url('2.jpg ');background-repeat:no-repeat;background-position:center;background-size:100%;width="50%"" height="500" --> <td>


<form action="">

<fieldset>
	<legend>FORGOT PASSWORD</legend>
	<b>Enter Email :</b><input name="aemail" type="text"/><hr/>
	<input type="submit" value="submit"/>

</fieldset>




</form>



</td>
</tr>
</table><br/>
</form>

