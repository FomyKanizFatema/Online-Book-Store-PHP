<?php
	session_start();
//include ('session.php');
	$currentUser=$_SESSION['currentUser'];
	
?>
<html>
	<head>
		<title>Tienda De Floris</title>
	</head>
	<body>
		<?php include("header.php");?>
				
		<table align="center">
			<tr>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
			</tr>
			
			<tr>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 00.00 <br/><br/><a href="usercard12.php"> Add to cart</a></td>
						</tr>
					</table>
					
				</td>
			</tr>
			
		</table>
						
			
	</body>
</html>