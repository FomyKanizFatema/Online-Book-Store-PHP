<?php include("headerUserSignedIn.php");?>
<html>
	<head>
	</head>
	<body width="95%" >
		<table border='1' width="100%" align="center">
			<tr>
				<td width="20%" > 
					<table cellpadding="15px">
						<tr ><th ><h3>Account</h3></th></tr>
						<tr align="center"><td><a href="bord.php">Dashboard</td></tr>
						<tr align="center"><td><a href="View_User_Profile.php">View Profile</td></tr>
						<tr align="center"><td><a href="Edit_User_Profile.php">Edit Profile</td></tr>
						<tr align="center"><td><a href="Change_User_Picture.php">Change Profile Picture</td></tr>
						<tr align="center"><td><a href="Change_User_Pass.php">Change Password</td></tr>						
					</table>
				</td>
				<td width="80%">
						<table align="center">
			<tr>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
			</tr>
			
			<tr>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
		
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
				
				</td>
				<td>
					<table align="center" border='1'>
						<tr>
							<td><a href="orderhistory.php"><img src="c.png" height="50%" /></a></td>
						</tr>
						<tr>
							<td align="center">Price : 0.0 | <a href="itemDetail.php"><input type="button" value="Details"/></a> |  <a href="userhome.php"><input type="button" value="Order"/></td>
						</tr>
					</table>
					
				</td>
			</tr>
			
		</table>
						
			
				
				</td>
			</tr>
		</table>
	</body>
</html>